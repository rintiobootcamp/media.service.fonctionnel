package com.bootcamp.services;

/**
 * Created by darextossa on 11/28/17.
 */
public class AwsService {
}
